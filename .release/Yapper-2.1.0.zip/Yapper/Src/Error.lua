--[[
    Error.lua
    Centralised error codes, formatted printing, and fatal throws.
]]

local YapperName, YapperTable = ...

local Error = {}
YapperTable.Error = Error

-- Localise Lua globals for performance
local string_format = string.format
local table_concat  = table.concat
local type   = type
local pairs  = pairs
local select = select
local unpack = unpack
local error  = error

-- ---------------------------------------------------------------------------
-- Error code catalogue
-- ---------------------------------------------------------------------------
local CODE = {
    -- Arguments
    BAD_STRING                     = "String is malformed and cannot be posted: %s",
    BAD_ARG                        = "Function %s expected a %s, but received a %s.",

    -- Frames / events
    EVENT_REGISTER_MISSING_FRAME   = "Tried to register event %s on frame %s, but it doesn't exist.",
    EVENT_UNREGISTER_MISSING_FRAME = "Tried to unregister event %s on frame %s, but it doesn't exist.",
    EVENT_HANDLER_NOT_FUNCTION     = "Handler for event %s is not a function.",
    MISSING_UTILS                  = "YapperTable.Utils is missing — did it fail to load?",
    MISSING_CONFIG                 = "YapperTable.Config is missing — did it fail to load?",
    MISSING_EVENTS                 = "YapperTable.Events is missing — did it fail to load?",
    MISSING_FRAMES                 = "YapperTable.Frames is missing — did it fail to load?",
    MISSING_INTERFACE              = "YapperTable.Interface (PurgeRenderCache) is missing — critical failure during boot.",

    -- Frames
    HOOKS_NOT_TABLE                = "Hooks were not a table for frame %s.",
    HOOK_NOT_FUNCTION              = "Hook %s for frame %s is not a function.",

    -- Patches
    BAD_PATCH                      = "Failed to apply patch for %s.",
    PATCH_MISSING_COMPATLIB        = "CompatLib missing — patches will not work.",
    YAPPER_MISSING_COMPATLIB       = "CompatLib not found; compatibility patches disabled.",

    -- Chat
    BAD_CHAT_TYPE                  = "Unsupported chat type: %s",

    -- Generic
    UNKNOWN                        = "Unknown error. String: %s || Detail: %s",
}

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------

--- Pad/trim variadic args to match the number of %s placeholders in `str`.
local function FormatSafe(str, ...)
    local args = { ... }
    local count = select(2, str:gsub("%%s", ""))

    -- Too many args — concatenate extras into the last slot.
    if #args > count and count > 0 then
        local extras = {}
        for i = count + 1, #args do extras[#extras + 1] = tostring(args[i]) end
        args[count] = (args[count] or "") .. " " .. table_concat(extras, " ")
        for i = #args, count + 1, -1 do args[i] = nil end
    end

    -- Too few args — pad with "".
    while #args < count do args[#args + 1] = "" end

    return string_format(str, unpack(args))
end

-- ---------------------------------------------------------------------------
-- Public API
-- ---------------------------------------------------------------------------

--- Print a formatted error without halting execution.
function Error:PrintError(code, ...)
    local template = CODE[code] or CODE.UNKNOWN
    local msg = FormatSafe(template, ...)
    if code == "UNKNOWN" and YapperTable.Config.System.DEBUG then
        msg = msg .. " — " .. (debugstack(2, 1, 0) or "")
    end
    YapperTable.Utils:Print("warn", "Error: " .. msg)
end

--- Print a formatted error AND halt execution (error()).
function Error:Throw(code, ...)
    self:PrintError(code, ...)
    local template = CODE[code] or CODE.UNKNOWN
    local msg = FormatSafe(template, ...)
    if code == "UNKNOWN" and YapperTable.Config.System.DEBUG then
        msg = msg .. "\n" .. (debugstack(2, 5, 0) or "")
    end
    error(msg)
end
